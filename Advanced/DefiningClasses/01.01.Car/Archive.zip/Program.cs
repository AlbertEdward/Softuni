﻿using System;
using System.Text;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new Car();

            StringBuilder sb = new StringBuilder();
            car.Make = "VW";
            car.Model = "MK3";
            car.Year = 1992;

            sb.AppendLine($"Make: {car.Make}");
            sb.AppendLine($"Model: {car.Model}");
            sb.AppendLine($"Year: {car.Year}");


            

            //Console.WriteLine($"Make: {car.Make}\nModel: {car.Model}\nYear: {}");

            Console.WriteLine(sb);
        }
    }
}
